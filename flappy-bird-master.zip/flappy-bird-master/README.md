flappy-bird
===========

a html5 game developed with phaser

demo <http://chaping.github.io/game/flappy-bird>

教程：<http://www.cnblogs.com/2050/p/3790279.html>
